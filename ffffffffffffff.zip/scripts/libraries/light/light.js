//main
const lightSourceLib = require("unity/libraries/light/lightSource");
module.exports = {
  lightSource: lightSourceLib
}
