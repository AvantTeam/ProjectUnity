//acts as a full-block prism, providing light across its surface.
//functionally, acts as a full-block reflector.
//extends lightConsumer
