const prspiboss = extendContent(UnitType, "stormpede", {
	load(){
		this.super$load();
		this.region = Core.atlas.find(this.name);
	},
});

prspiboss.constructor = () => {
	const unit = extend(UnitEntity, {
		kill(){
			this.super$kill();
			var c = UnitTypes.crawler.create(this.team);
			c.set(this.x, this.y);
			c.add();
		}
	});
	return unit;
}