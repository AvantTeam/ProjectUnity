const dialtest = extendContent(Block, "dialog-test", {});

dialtest.buildType = () => {
	return extendContent(Building, dialtest, {
		
	})
}