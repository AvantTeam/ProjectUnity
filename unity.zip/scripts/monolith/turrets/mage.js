const mage = extendContent(PowerTurret, "mage", {});
