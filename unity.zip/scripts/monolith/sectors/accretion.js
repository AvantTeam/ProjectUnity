const accretion = new SectorPreset("accretion", global.unity.megalith, 30);
accretion.alwaysUnlocked = true;
accretion.captureWave = 15;
