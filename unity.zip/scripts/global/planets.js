module.exports = {
	megalith: require("unity/monolith/planets/megalith"),
	electrode: require("unity/imber/planets/electrode")
};
