//This is used for multi use or extra sounds only.

module.exports = {
	endgameSmallShoot: loadSound("end/endgame-small-shoot"),
	beamIntenseHighpitchTone: loadSound("beam-intense-highpitch-tone")
}
