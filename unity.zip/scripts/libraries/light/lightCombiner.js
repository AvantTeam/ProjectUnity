//extends lightConsumer
