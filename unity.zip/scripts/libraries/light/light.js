//main
const lightSourceLib = require("unity/libraries/light/lightSource");
const lightConsLib = require("unity/libraries/light/lightConsumer");
module.exports = {
  lightSource: lightSourceLib,
  lightConsumer: lightConsLib
}
